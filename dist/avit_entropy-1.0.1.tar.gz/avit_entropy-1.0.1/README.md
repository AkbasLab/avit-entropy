# avit-entropy
A python module for calculating entropy of autonomous vehicle scenarios using information theory.

Example usage may be found at the [github repository](https://github.com/AkbasLab/avit-entropy-paper) where this module is introduced. 