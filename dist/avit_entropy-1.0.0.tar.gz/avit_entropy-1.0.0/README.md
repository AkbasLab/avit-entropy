# avit-entropy
A python module for calculating entropy of autonomous vehicle scenarios using information theory.
